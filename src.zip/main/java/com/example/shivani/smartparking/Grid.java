package com.example.shivani.smartparking;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.sql.Time;

public class Grid extends AppCompatActivity {

    AutoCompleteTextView at1,at2,at3,at4,at5;
    Button b1;
    DatabaseReference reff;
    user user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        at1 = (AutoCompleteTextView) findViewById(R.id.at1);
        at2 = (AutoCompleteTextView) findViewById(R.id.at2);
        at3 = (AutoCompleteTextView) findViewById(R.id.at3);
        at4 = (AutoCompleteTextView) findViewById(R.id.at4);
        at5 = (AutoCompleteTextView) findViewById(R.id.at5);
        b1 = (Button) findViewById(R.id.b1);

        user = new user();

        reff = FirebaseDatabase.getInstance().getReference().child("user");

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Long phn_no = Long.parseLong(at2.getText().toString().trim());

                user.setName(at1.getText().toString().trim());
                user.setVehicle_no(at3.getText().toString().trim());
                user.setMob_no(phn_no);
                user.setEntry_time(at4.getText().toString().trim());
                user.setExit_time(at5.getText().toString().trim());

                reff.push().setValue(user);
                Toast.makeText(Grid.this, "data inserted successfully", Toast.LENGTH_LONG).show();


                String mn,vn,ent,ext;
                mn = at2.getText().toString();
                vn = at3.getText().toString();
                ent = at4.getText().toString();
                ext = at5.getText().toString();
                int amt = (Integer.parseInt(ext)-Integer.parseInt(ent))*10;
                Intent i = new Intent(Grid.this, payment.class);
                i.putExtra("Mobile_Number",mn);
                i.putExtra("Vehicle_Number",vn);
                i.putExtra("Entry_time",ent);
                i.putExtra("Exit_time",ext);
                String amt1=Integer.toString(amt);
                i.putExtra("Amount",amt1);
                startActivity(i);


            }
        });

    }
}
