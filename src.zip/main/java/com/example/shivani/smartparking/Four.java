package com.example.shivani.smartparking;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import java.util.List;


public class Four extends ArrayAdapter<user>
{
public Button buttonf;

    List<user> usr;

    private Activity context;
    public Four(Activity context, List<user> usr) {
        super(context, R.layout.grid_layout, usr);
        this.context = context;

    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listItem = inflater.inflate(R.layout.grid_layout, null, true);

         TextView t = (TextView) listItem.findViewById(R.id.nm);
         TextView no=(TextView) listItem.findViewById(R.id.mno);
         TextView vo=(TextView) listItem.findViewById(R.id.vno);
        TextView et=(TextView) listItem.findViewById(R.id.entime);
        TextView ext=(TextView) listItem.findViewById(R.id.extime);
       // Button  b=(Button)listItem.findViewById(R.id.button6);

        user artist = usr.get(position);
        t.setText(artist.getName());
        no.setText(artist.getMob_no().toString());
        vo.setText(artist.getVehicle_no());
        et.setText(artist.getEntry_time());

        ext.setText(artist.getExit_time());
        return listItem;
    }



}

