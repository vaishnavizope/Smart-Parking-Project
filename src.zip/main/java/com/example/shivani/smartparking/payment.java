package com.example.shivani.smartparking;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class payment extends AppCompatActivity {
 TextView t1,t2,t3,t4,t5,t6;
 Button b;
 String s1,s2,s3,s4;
 String s5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        t1 = findViewById(R.id.textView6);
        t2 = findViewById(R.id.textView7);
        t3 = findViewById(R.id.textView8);
        t4 = findViewById(R.id.textView9);
        t5 = findViewById(R.id.textView4);
        t6 = findViewById(R.id.Text3);

        Intent i = getIntent();
        s1 = i.getExtras().getString("Mobile_Number");
        s2 = i.getExtras().getString("Vehicle_Number");
        s3 = i.getExtras().getString("Entry_time");
        s4 = i.getExtras().getString("Exit_time");
        s5 = i.getExtras().getString("Amount");

        t1.setText(s1);
        t2.setText(s2);
        t3.setText(s3);
        t4.setText(s4);
        t6.setText(s5);


        b=findViewById(R.id.Payment);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Toast.makeText(payment.this, "Your booking is confirmed ", Toast.LENGTH_LONG).show();


            }
        });

    }
}
