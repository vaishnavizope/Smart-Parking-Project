package com.example.shivani.smartparking;

import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Listmall extends AppCompatActivity {

    DatabaseReference show;
    //Malls malls;
    List<Malls> malls;

    ListView lstamll;
    private static final String TAG = "Listmall";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listmall);
        show = FirebaseDatabase.getInstance().getReference().child("Malls");
        malls=new ArrayList<>();
        lstamll=findViewById(R.id.List_view);
        Toast.makeText(Listmall.this,"data"+show.getDatabase(),Toast.LENGTH_LONG).show();

        //  malls=new Malls();
        show.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //  malls.clear();
                Toast.makeText(Listmall.this,"data inserted successfully 2"+dataSnapshot.getChildren(),Toast.LENGTH_LONG).show();

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren())
                {

                    Malls mal=postSnapshot.getValue(Malls.class);
                    malls.add(mal);

                    Log.d(TAG,"data "+mal.getId());
                }


                MallList mlist=new MallList(Listmall.this,malls);
                lstamll.setAdapter(mlist);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w(TAG, "Failed to read value.", databaseError.toException());
                Toast.makeText(Listmall.this,"data inserted ERROR1",Toast.LENGTH_LONG).show();

            }
        });
       // Toast.makeText(Listmall.this,"data inserted successfully",Toast.LENGTH_LONG).show();



    }
    @Override
    protected void onStart() {
        super.onStart();


    }
}
