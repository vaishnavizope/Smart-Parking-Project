package com.example.shivani.smartparking;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class GuardSide extends AppCompatActivity {
    Button b1,b2;
    DatabaseReference firebaseDatabase,firebaseDatabase1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guard_side);
        b1=findViewById(R.id.resrve);
        b2=findViewById(R.id.free);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(GuardSide.this,ConfirmBook.class);
                startActivity(i);
            }
        });
    }
    public void remove(View view)
    {
        View mView = getLayoutInflater().inflate(R.layout.custom1_dialog,null);
        final EditText txt_inputText = (EditText) mView.findViewById(R.id.pt);
        final AlertDialog.Builder alert  = new AlertDialog.Builder(GuardSide.this);
        Button can  = mView.findViewById(R.id.btn);
        Button okk  = (Button)mView.findViewById(R.id.btn2);
        alert.setView(mView);
        final AlertDialog alertDialog = alert.create();
        alertDialog.setCanceledOnTouchOutside(false);
        can.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });
        okk.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                final ProgressDialog progressDialog;
                firebaseDatabase = FirebaseDatabase.getInstance().getReference().child("user");
                firebaseDatabase1 = FirebaseDatabase.getInstance().getReference().child("Malls");
                progressDialog = new ProgressDialog(GuardSide.this);
                progressDialog.setTitle("Delete Value");
                progressDialog.setMessage("Deleting...");
                progressDialog.show();
                firebaseDatabase.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        //  malls.clear();
                        //Toast.makeText(Listmall.this,"data inserted successfully 2"+dataSnapshot.getChildren(),Toast.LENGTH_LONG).show();
                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren())
                        {
                            user mal=postSnapshot.getValue(user.class);
                            // Toast.makeText(AdminActivity.this,"delete "+mal.getId(),Toast.LENGTH_LONG).show();
                            if(mal.getVehicle_no().toString().equals(txt_inputText.getText().toString())) {
                                progressDialog.hide();
                                Toast.makeText(GuardSide.this, "delete " + dataSnapshot.getKey(), Toast.LENGTH_LONG).show();
                                postSnapshot.getRef().removeValue();
                            }
                        }
           //             databaseEvent.child(event.getEventId()).child("Malls").setValue(Integer.parseInt(dataSnapshot.getValue().toString()) + 1);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });
            }
        });
        alertDialog.show();
    }


}
