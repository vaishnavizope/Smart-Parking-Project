package com.example.shivani.smartparking;

public class Malls
{
    private String name;
    private Integer twoPark,id;
    private Integer fourpark;
    private Integer fourAva;
    private Integer twoAva;

    public Integer getFourAva() {
        return fourAva;
    }

    public void setFourAva(Integer fourAva) {
        this.fourAva = fourAva;
    }

    public Integer getTwoAva() {
        return twoAva;
    }

    public void setTwoAva(Integer twoAva) {
        this.twoAva = twoAva;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer gettwoPark() {
        return twoPark;
    }

    public void settwoPark(Integer twoPark) {
        this.twoPark = twoPark;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getFourpark() {
        return fourpark;
    }

    public void setFourpark(Integer fourpark) {
        this.fourpark = fourpark;
    }
}
