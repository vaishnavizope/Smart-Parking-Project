package com.example.shivani.smartparking;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class MallList extends ArrayAdapter<Malls>
{


    List<Malls> malls;
    private Activity context;

    public MallList(Activity context, List<Malls> malls) {
        super(context, R.layout.list_layout, malls);
        this.context = context;
        this.malls = malls;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.list_layout, null, true);

        TextView textViewName = (TextView) listViewItem.findViewById(R.id.textView);
        TextView textViewtwo = (TextView) listViewItem.findViewById(R.id.textView2);
        TextView textViewfour = (TextView) listViewItem.findViewById(R.id.textView3);
        TextView textviewid=(TextView)listViewItem.findViewById(R.id.textView5);

        Malls artist = malls.get(position);
        textViewName.setText(artist.getName());
        textViewtwo.setText(artist.gettwoPark().toString());
        textViewfour.setText(artist.getFourpark().toString());
        textviewid.setText(artist.getId().toString());
        return listViewItem;
    }
}
