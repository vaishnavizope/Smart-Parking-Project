package com.example.shivani.smartparking;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddMall extends AppCompatActivity {

    DatabaseReference add1;
    Malls malls;
    EditText mallname,two,four,id;
    Button addmall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_add_mall);

        mallname=findViewById(R.id.name);
        two=findViewById(R.id.twoW);
        four=findViewById(R.id.fourW);
        addmall=findViewById(R.id.button);
        id=findViewById(R.id.editText2);

        malls=new Malls();

        add1 = FirebaseDatabase.getInstance().getReference().child("Malls");

        addmall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int two1=Integer.parseInt(two.getText().toString().trim());
                int four1=Integer.parseInt(four.getText().toString().trim());
                int id1=Integer.parseInt(id.getText().toString().trim());
                int available2=two1;
                int available4=four1;
                malls.setName(mallname.getText().toString().trim());
                malls.settwoPark(two1);
                malls.setFourpark(four1);
                malls.setFourAva(available4);
                malls.setTwoAva(available2);
                malls.setId(id1);


                add1.push().setValue(malls);
                Toast.makeText(AddMall.this,"Mall added successfully",Toast.LENGTH_LONG).show();

            }
        });


    }
}
