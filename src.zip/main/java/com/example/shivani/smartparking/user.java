package com.example.shivani.smartparking;

public class user
{
    private String name;
    private Long mob_no;
    private String vehicle_no;

    public String getVehicle_no() {
        return vehicle_no;
    }

    public void setVehicle_no(String vehicle_no) {
        this.vehicle_no = vehicle_no;
    }

    private String entry_time;
    private String exit_time;

    public user() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getMob_no() {
        return mob_no;
    }

    public void setMob_no(Long mob_no) {
        this.mob_no = mob_no;
    }


    public String getEntry_time() {
        return entry_time;
    }

    public void setEntry_time(String entry_time) {
        this.entry_time = entry_time;
    }

    public String getExit_time() {
        return exit_time;
    }

    public void setExit_time(String exit_time) {
        this.exit_time = exit_time;
    }
}
