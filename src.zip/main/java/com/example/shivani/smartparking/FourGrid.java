package com.example.shivani.smartparking;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FourGrid extends AppCompatActivity
{

    DatabaseReference showuser;
    //Malls malls;
    List<user> usr;

    ListView grid1;
    private static final String TAG = "FourGrid";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_four_grid);
        showuser = FirebaseDatabase.getInstance().getReference().child("user");
        usr=new ArrayList<>();
        grid1=findViewById(R.id.grid);
        Toast.makeText(FourGrid.this,"data"+showuser.getDatabase(),Toast.LENGTH_LONG).show();

        //  malls=new Malls();
        showuser.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //  malls.clear();
                Toast.makeText(FourGrid.this,"data inserted successfully 2"+dataSnapshot.getChildren(),Toast.LENGTH_LONG).show();

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren())
                {

                    user mal=postSnapshot.getValue(user.class);
                    usr.add(mal);

                    Log.d(TAG,"data "+mal.getVehicle_no());
                }


                Four list=new Four(FourGrid.this,usr);
                grid1.setAdapter(list);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w(TAG, "Failed to read value.", databaseError.toException());
                Toast.makeText(FourGrid.this,"data inserted ERROR1",Toast.LENGTH_LONG).show();

            }
        });




    }
    @Override
    protected void onStart() {
        super.onStart();


    }
}
